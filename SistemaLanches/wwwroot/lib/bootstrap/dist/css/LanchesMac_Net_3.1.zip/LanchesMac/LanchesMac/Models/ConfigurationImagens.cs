﻿namespace LanchesMac.Models
{
    public class ConfigurationImagens
    {
        public string NomePastaImagensProdutos { get; set; }
    }
}
